Autonote('amberDungeonFountain6', 1, 'Amber Island, Castle Amber: Upper corridor entrance, +10 SP restored')
Autonote('amberDungeonFountain7', 1, 'Amber Island, Castle Amber: Upper corridor, +15 AC')
