offsets = {
	GameName = "LuaConsole",
	LogFileName = "log.txt",
	CoreFiles = {
		internal.CoreGamePath.."Scripts/Core/interact.lua",
	}
}

debug.getregistry().GitPath = nil
