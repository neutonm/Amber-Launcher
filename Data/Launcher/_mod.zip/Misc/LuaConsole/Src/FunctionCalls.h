#pragma once

extern char TextBuffer[];

void RegisterFunctionCalls();
