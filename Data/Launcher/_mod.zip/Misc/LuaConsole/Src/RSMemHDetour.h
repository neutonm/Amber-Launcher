extern "C"
{
	#include "lua.h"
}
void RSMemHDetourRegister(lua_State *L);