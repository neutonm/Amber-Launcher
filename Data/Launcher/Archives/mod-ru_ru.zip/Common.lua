LocalizeAll({
	Autonotes = {
		[".\\maps\\amber:amberFountain1"] = "Amber Island, Port Island: + 10 Hit and Spell points",
		[".\\maps\\amber:amberWell1"] = "Amber Island, Port Island: Behind Powder Kegg Inn, +5 AC",
		[".\\maps\\amber:amberWell2"] = "Amber Island, Town SW: Near Leary residence, +10 Might",
		[".\\maps\\amber:amberWell3"] = "Amber Island, Swamp Island: Between Statue and Knight Camp, +5 Elemental Resistance",
		[".\\maps\\applecave:amberDungeonFountain2"] = "Amber Island, Apple Cave: Entrance, near the mine cart, +20 Luck",
		[".\\maps\\applecave:amberDungeonFountain3"] = "Amber Island, Apple Cave: Temple, +10 SP restored",
		[".\\maps\\archmageres:amberDungeonFountain4"] = "Amber Island, Archmage Residence: Entrance, Main Hall, +10 HP/SP restored",
		[".\\maps\\oakhome:amberDungeonFountain1"] = "Amber Island, Oak Hill Cottage: Entrance corridor, +5 AC",
		[".\\maps\\secret:amberDungeonFountain5"] = "Amber Island, Secret Hideout: Entrance, +10 HP/SP restored",
		[".\\maps\\testlevel:amberDungeonFountain6"] = "Amber Island, Castle Amber: Upper corridor entrance, +10 SP restored",
		[".\\maps\\testlevel:amberDungeonFountain7"] = "Amber Island, Castle Amber: Upper corridor, +15 AC"
	}
}, true)
