--------------------------------------------------------------------------------
-- (447) Maximus
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 447, Slot = -1"] = {
	FirstGreet = "Greetings adventurers! I wasn't sure you would show up, but here you are.",
	Greet = "Ah, adventurers, you're back. Any good news?"
}

LocalizeAll.Quests["NPC = 447, Slot = 0"] = {
	Done = "*Maximus takes the letter and reads it carefully.*\
\
Well done. Delivering a message to Sir Greene may be a small task, but you've proven your worthiness for more significant challenges.\
\
For now, \01265523our payment is my trust.\01200000",
	Give = "Many have stood where you stand, seeking to prove themselves. I need more than just willingness; I need proof of capability. I'll give you a chance to prove you're different.\
\
Your first task will be a simple yet vital one. Travel to the knight's camp located in the \01265523southeastern swamp of Amber Island\01200000. There, you will find \01265523Sir Greene\01200000. Deliver this letter to him and return with his response.Consider this a test of your reliability. Succeed, and perhaps you'll prove yourselves worthy of more substantial undertakings.",
	Quest = "\"Story: Legate\"\
Mayor Maximus, Amber Island, Town Hall\
\
Deliver a letter to Sir Robert Greene at the knight's camp located in the southeastern swamp of Amber Island.",
	Topic = "Story Quest: Legate",
	Undone = "Well? Sir Greene awaits your arrival in the \01265523southeastern swamp\01200000. I expect you to bring me his response. Off you go!"
}

LocalizeAll.Quests["NPC = 447, Slot = 0 +"] = {
	Done = "Magnus wasn't in his residence? Disappointing, yet it does help narrow our search. This letter to his butler is our only lead. Luckily, the butler is in our custody. It's time we had a chat with him to see what more we can uncover.",
	Give = "With your capabilities confirmed, it's time to address a pressing matter:\01265523 locating Archmage Magnus\01200000. His mist machine prevents ships from safely docking at Amber Island, and his goblins have been forcing us to comply with his demands for gold. While it's not as critical as the mist machine situation, his capture is imperative to prevent further harm. His residence is guarded. Start there. Maybe once we have him in our custody, he will finally listen to reason.\
\
Many have attempted to capture Magnus and failed. The last group of adventurers who tried were massacred. The sole survivor frequents the \01265523Crusty Eagle Inn\01200000. He might have valuable insights. You should \01265523consult with him\01200000 to aid your search for the archmage.",
	Quest = "\"Story: Investigation\"\
Mayor Maximus, Amber Island, Town Hall\
\
Search for Archmage Magnus on the island by investigating his residence for clues to his whereabouts.",
	Topic = "Story Quest: Investigation",
	Undone = "Why are you here? Have you located the Archmage? You aren't taking this as seriously as you should. If Magnus is not brought to justice, we will all suffer.\
\
\01265523Don't forget to consult with that adventurer at the Crusty Eagle Inn.\01200000"
}

LocalizeAll.Quests["NPC = 447, Slot = 0 + +"] = {
	Done = "You were so close to capturing him. It's unfortunate he escaped at the last moment.\
\
Nevertheless, you've outdone all others in this pursuit, and now we have a definitive lead. He's taken refuge in \01265523Castle Amber!\01200000\
\
The pieces are falling into place. We weren't sure why the goblins were so concentrated around Castle Amber, but now it just seems obvious. We must prepare for the next move.",
	Give = "Excellent work uncovering this letter and confirming the Archmage's absence from his residence. This is significant progress. We must press our advantage. The butler, already in our custody, could hold the key to Magnus's hideout. \01265523Interrogate him\01200000. He may reveal the information we need to advance our pursuit. You can find him in the town \01265523jail\01200000.",
	Quest = "\"Story: Secret Hideout\"\
Mayor Maximus, Amber Island, Town Hall\
\
Hunt down Magnus in his secret hideout. Use the teleportation platform near the knight's camp in the swamp to get there.",
	Topic = "Story Quest: Secret Hideout",
	Undone = "Time is of the essence. With the information we have on Magnus's location, we must act swiftly and \01265523capture him\01200000 before he slips away again."
}

LocalizeAll.Quests["CoreQuest"] = {
	After = "Thank you once again, my heroes. Amber island will never forget your heroic deeds.",
	Give = "You've proven yourselves trustworthy, and frankly, you're the only one who can stand up to Magnus's monsters. We need your help to defeat him. I'm ordering an attack on Castle Amber. Magnus's goblins will easily repel our attack, but our attack will only be a diversion.\
\
While our forces engage the goblin army, you will \01265523enter the castle\01200000 through the back, find Magnus, and \01265523destroy his mist machine\01200000. I know I asked you to capture him before, but I doubt he will listen to reason. You know what has to be done. This operation is risky, but it's our best chance to end this crisis. Once you're prepared, you can \01265523head to the boathouse and find the boatmaster, Cedrick Boyce.\01200000\
\
As soon as Cedrick takes you to the island, \01265523our army will strike the goblins\01200000, allowing you an opportunity to get into \01265523Castle Amber\01200000.",
	Quest = "Story: The Mist\
Mayor Maximus, Amber Island, Town Hall\
\
Contact boatmaster Cedrick Boyce to secure passage to Castle Amber's back entrance. Infiltrate the castle, eliminate Archmage Magnus, and destroy his mist machine.",
	Topic = "Story Quest: The Mist",
	TopicDone = "Thanks: The Mist",
	Undone = "I understand you may need some time to prepare, but every day we spend under Magnus's thumb brings us closer to ruin. As soon as you can, \01265523infiltrate the castle\01200000 and bring this ordeal to a close. \01265523Find boatmaster Cedrick Boyce, take a boat to the island\01200000, and we will send our forces to divert their defenders while you enter Castle Amber."
}

LocalizeAll.Quests["NPC = 447, Slot = 1"] = {
	Topic = "Archmage Crisis",
	Ungive = "We've been ensnared in an extortion racket by one of our own, Magnus the Archmage. He's created a remarkable weather machine that produces thick fog around Amber Island, complicating navigation for ships at sea.\
\
Magnus only shuts it off when we pay him a hefty sum of gold. As the fog grows more widespread by the day, so does the price for his \"services.\" If we don't put an end to his actions, our island faces disaster. It's not just financial trouble if the ships stop coming. We can only grow so much of our own food."
}

LocalizeAll.Quests["NPC = 447, Slot = 2"] = {
	Topic = "Invaders",
	Ungive = "A horde of goblins has taken over Castle Amber, and it's astonishing to see them following a swamp troll as their leader. Trolls are known cannibals. Have the goblins considered that once the troll runs out of human prey, they will be the next on the menu?"
}

LocalizeAll.Quests["NPC = 447, Slot = 3"] = {
	Done = "You've done a good deed by bringing this to light. Planning an assassination is a grave matter, and it shall not be taken lightly. Rest assured, appropriate actions will be taken against Otho for such a heinous plot. Thank you.",
	Topic = "Quest: Revenge",
	Undone = "Otho Robeson hired you to assassinate Michael Cassio? Do you have any proof?"
}

--------------------------------------------------------------------------------
-- (449) Sir Henry
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 449, Slot = -1"] = {
	FirstGreet = "Greetings and Salutations, adventurer. My name is Henrik Chukhran and i'm creator of this mod.\
\
Welcome to the Amber Island! \
\
I hope you enjoy this mod as much as I enjoyed creating it.\
\
Good luck!",
	Greet = "Greetings and Salutations, adventurer. My name is Henrik Chukhran and i'm creator of this mod.\
\
Welcome to the Amber Island! \
\
I hope you enjoy this mod as much as I enjoyed creating it.\
\
Good luck!"
}

LocalizeAll.Quests["NPC = 449, Slot = 0"] = {
	Topic = "Features",
	Ungive = "This mod introduces several of new features as well as bunch of quality-of-life tweaks:\
* Unique levels that push the limits of the old game engine, offering much higher quality than the original game.\
\
* A mercenary mechanic with special summoned upgradeable monsters that will fight alongside you. \
\
* Expert teachers can teach their skill with a 20% discount.\
\
* Temple resurrection: If you die, you will be respawned near the entrance of the last temple you visited.\
\
.. and lots of minor stuff that you might notice in time."
}

LocalizeAll.Quests["NPC = 449, Slot = 1"] = {
	Topic = "Discord",
	Ungive = "I invite you to join the mod's Discord channel, where we can discuss the mod and everything related to Might and Magic. Please report any bugs there as well.\
\
Link:\
https://discord.gg/MhmZGrGxV4"
}

LocalizeAll.Quests["NPC = 449, Slot = 2"] = {
	Topic = "Future & Support",
	Ungive = "I plan to continue developing the mod with the aim of creating a full-fledged adventure featuring numerous outdoor maps and a plethora of dungeons, all designed to offer a gameplay experience reminiscent of the original games.\
\
Your support is invaluable to the continued development of this mod. The best way to support this project is through Patreon.:\
\
www.patreon.com/HenrikChukhran\
\
Check out mod's Website: www.mightandmagicmod.com"
}

LocalizeAll.Quests["NPC = 449, Slot = 3"] = {
	Topic = "Special Thanks!",
	Ungive = "Big thanks to Sergey Rozhenko aka GrayFace for making wonderful tools such as MMEditor and MMExtension which made it possible to make this mod.\
\
I'd like to thank my first patreon supporterers - without you this wouldn't be possible at all: BVB, Alkapivo, Dr. Matt Barton, DakiMana, Rapscallion, FarOffNebula, Simply Be, Luc Nunya, Simon Poirot, Elric D, Outbox, Rabid_Wolverine, Mathias.\
\
Special thanks to Alkapivo for his long-time support, inspiring and motivational strong belief, and dedication to the project.\
\
Extra credits:\
eksekk - for technical help\
Bademus Octavian Juvenal - for concept and fan art\
DMStaley - for text reviews and contributions\
\
Alkapivo, Cayhen_, DMStaley, Eevee Chan, Malekith, Nak, Angstschweiss, Bunny, Loki, Singatias - for beta test participation."
}

--------------------------------------------------------------------------------
-- (450) Eleric Graywood
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 450, Slot = -1"] = {
	FirstGreet = "Greetings! The spark in your eyes suggests you've come to our island seeking adventure, am I right? You should visit the mayor of Amber Town, Maximus. Word has it he's looking for adventurers willing to risk everything. There's a substantial reward, of course.",
	Greet = "Greetings! The spark in your eyes suggests you've come to our island seeking adventure, am I right? You should visit the mayor of Amber Town, Maximus. Word has it he's looking for adventurers willing to risk everything. There's a substantial reward, of course."
}

LocalizeAll.Quests["NPC = 450, Slot = 0"] = {
	Topic = "The Island",
	Ungive = "Amber Island is a trading hub for many merchants worldwide. Gold flows through the island's veins, drawing fortune seekers of all kinds. Yourselves included, I presume.\
\
Regrettably, this wealth also draws troublemakers. Normally, we'd hire guards, but Archmage Magnus has taken over that role without asking us. Hopefully, the mayor will sort this out before we're bled dry."
}

LocalizeAll.Quests["NPC = 450, Slot = 1"] = {
	Topic = "Amber?",
	Ungive = "Before it became a commercial hub, this place was the most abundant source of amber in the world for many decades. The name stuck, though nowadays, you'd be lucky to find a piece of amber. The miners extracted the last remnants a few years back."
}

--------------------------------------------------------------------------------
-- (451) William Nightkeep
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 451, Slot = -1"] = {
	FirstGreet = "Adventurers! I don't know how you got here, but it seems you're stuck with us now.",
	Greet = "Adventurers! I don't know how you got here, but it seems you're stuck with us now."
}

LocalizeAll.Quests["NPC = 451, Slot = 0"] = {
	Topic = "Difficult Times",
	Ungive = "Sometimes, the mist manages to seep into the island area. Even though the \01265523Powder Keg Inn\01200000 is just a few steps from my house, finding my way home after lingering there too long is a challenge. It gets so thick that I can barely see my own hands. Damn that archmage."
}

--------------------------------------------------------------------------------
-- (452) Aria Nightkeep
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 452, Slot = 0"] = {
	Topic = "Husband",
	Ungive = "William earns his living as a mercenary, safeguarding trade ships. Unfortunately, Archmage Magnus's mist has significantly disrupted the trade routes, so there's not a lot of mercenary work. As a result, William spends most of his days at the Inn, often drinking until he's three sheets to the wind. I do wish he'd find some temporary work or at least lend a hand around the house."
}

LocalizeAll.Quests["NPC = 452, Slot = 1"] = {
	Topic = "Mercenaries",
	Ungive = "Amber Island is a city state, so we hire our own mercenaries to keep us safe. If we let the monarchs on the mainland send their soldiers here, we'd have to start following their laws and paying them taxes."
}

--------------------------------------------------------------------------------
-- (453) Harley Payne
--------------------------------------------------------------------------------

LocalizeAll.Quests["AmberMisc2"] = {
	Done = "Perfect, this looks like everything. Give me a moment to mix them together...\
\
*After a short wait, she returns with a shimmering, \01265523black potion of profound Personality.\01200000*",
	Give = "As an expert alchemist, I specialize in crafting the finest potions, including the renowned \01265523Potion of Personality\01200000. Provide me with the necessary ingredients, and I'll prepare one for you.\
\
I require \012655233\01200000 ingredients from each of these categories: \01265523red\01200000, \01265523blue\01200000, and \01265523yellow\01200000.",
	Topic = "Make: Black Potion (Personality)",
	Undone = "Don't forget, I need \012655233\01200000 ingredients from each of these categories: \01265523red\01200000, \01265523blue\01200000, and \01265523yellow\01200000."
}

--------------------------------------------------------------------------------
-- (455) Woodrow Marley
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 455, Slot = 1"] = {
	Topic = "Sour Apples",
	Ungive = "You'll find the apples on this island to be almost punishingly sour. Even biting into one is like a test of endurance!\
\
However, they do have one saving grace: these apples make for an excellent cider. In fact, the apple cider brewed here is hailed as some of the best in the world. It seems even the sourest fruits can produce remarkable results."
}

--------------------------------------------------------------------------------
-- (457) Robin Stringer
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 457, Slot = -1"] = {
	FirstGreet = "Welcome, traveler! I'm Robin Stringer, a bowyer and a master archer. Are you here to learn the fine art of shooting a bow?",
	Greet = "Welcome, traveler! I'm Robin Stringer, a bowyer and a master archer. Are you here to learn the fine art of shooting a bow?"
}

--------------------------------------------------------------------------------
-- (465) Valeria Timar
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 465, Slot = 1"] = {
	Topic = "Robert Stevenson",
	Ungive = "Have you heard whispers about Robert Stevenson? Some say that old sea dog might've been a pirate in his past, and let's be honest, there's no such thing as an ex-pirate. Keep your wits about you around him."
}

--------------------------------------------------------------------------------
-- (466) Oswald Of Umbria
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 466, Slot = 1"] = {
	Topic = "Apple Cave",
	Ungive = "Apple Island, \01265523located northwest of Amber Island\01200000, is home to the notorious Apple Cave. Despite the charming name, thanks to the abundant apple trees that grow there, it has been a haven for bandits and pirates for decades. Locals have tried several times to cleanse the area of its lawless residents, but like a bad weed, they keep coming back. It's a place best avoided unless you're looking for trouble, or perhaps an adventure."
}

--------------------------------------------------------------------------------
-- (471) Craig
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 471, Slot = 1"] = {
	Topic = "Craig's Story",
	Ungive = "I'm Craig, just a goblin trying to make ends meet in this bustling town. Found work at the smithy, fixing up whatever comes my way. Can't complain. Keeps the coin flowing, and it's better than working for Magnus."
}

--------------------------------------------------------------------------------
-- (477) Conrad Hawk 
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 477, Slot = -1"] = {
	FirstGreet = "Ah, my favourite people! What can I do for you today?",
	Greet = "Ah, my favourite people! What can I do for you today?"
}

LocalizeAll.Quests["NPC = 477, Slot = 1"] = {
	Topic = "Brawling!",
	Ungive = "Ah, brawling, there's nothing quite like it. You see, there's a certain art to landing the perfect punch, especially when it's someone's nose at the tavern on a lively evening. The thrill, the adrenaline rush... it's just how I like to unwind."
}

LocalizeAll.Quests["NPC = 477, Slot = 2"] = {
	After = "I've taught you everything I know, there's really nothing more I can show you. You've got all the techniques. Now it's all about perfecting them on your own.",
	Done = "Since you've helped me out, let me share a bit of my brawling expertise with you. It's all about speed and strength. Watch closely, train hard, and you'll find yourself hitting harder and moving faster before you know it.",
	Topic = "Reward: Might/Speed +5"
}

--------------------------------------------------------------------------------
-- (483) Timothy Leary
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 483, Slot = 1"] = {
	Topic = "The Doors of Perception",
	Ungive = "Welcome, seeker of the arcane! Interested in expanding your mind with some mind magic? It's like navigating a labyrinth where each turn reveals not walls, but windows into new dimensions. Imagine, if you will, tickling the very fabric of reality until it giggles back at you. That's mind magic! It's not just about bending thoughts, but about stretching them until they yawn and show you their secrets. Oh, and it can all be done in a fun way, too. I know a magical spell that'll make you perceive walls breathing and colors changing. So are you ready to open some doors in your mind, or perhaps slip through a few windows?"
}

--------------------------------------------------------------------------------
-- (485) James Gladwyn
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 485, Slot = -1"] = {
	FirstGreet = "James Gladwyn at your service!\
\
Oh, you're those \"new people\" everyone keeps talking about, right? Good. New people means more trade and more trade means more gold.",
	Greet = "James Gladwyn at your service!\
\
Oh, you're those \"new people\" everyone keeps talking about, right? Good. New people means more trade and more trade means more gold."
}

LocalizeAll.Quests["NPC = 485, Slot = 0"] = {
	Topic = "Wealth",
	Ungive = "You've probably  already heard, but this island bleeds gold. It's true! Once the top supplier of amber, it's now one of the most successful trade hubs in the world. But if you ask me, the real secret to its prosperity is the low taxation. It's practically non-existent."
}

--------------------------------------------------------------------------------
-- (486) Mark Bolton
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 486, Slot = 0"] = {
	Topic = "Goblins",
	Ungive = "I'm sure that even a powerful sorcerer like Magnus the Archmage realized he can't keep extorting us alone. That's why he brought several ships' worth of goblin mercenaries to back his cause. While most headed to the castle, others roam about, stirring up trouble. Be careful when traveling beyond the town."
}

--------------------------------------------------------------------------------
-- (487) Sheila Bolton
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 487, Slot = 0"] = {
	Topic = "The Payne Family",
	Ungive = "Ashley, my older sister, lives in a \01265523small hut to the southeast of Amber Island\01200000, nestled in the swampy area. If you're looking for an \01265523expert alchemist\01200000, she's the person you should seek out."
}

LocalizeAll.Quests["AmberMisc1"] = {
	Done = "You've already gathered all the ingredients? Excellent. Allow me a moment to prepare the potion...\
\
*After a brief period, she returns and presents you with a dark, swirling \01265523Potion of Pure Intelligence\01200000.*",
	Give = "I'm not exactly a master alchemist, but I do know how to concoct the \"specialty of the house\": the \01265523Potion of Pure Intelligence\01200000. If you provide the necessary ingredients, I'll be able to brew one for you.\
\
I require \012655233\01200000 ingredients from each of the following types: \01265523red\01200000, \01265523blue\01200000, and \01265523yellow\01200000.",
	Topic = "Make: Black Potion (Intelligence)",
	Undone = "Remember, I need \012655233\01200000 ingredients from each of the following types: \01265523red\01200000, \01265523blue\01200000, and \01265523yellow\01200000."
}

--------------------------------------------------------------------------------
-- (488) Julia Greene
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 488, Slot = -1"] = {
	FirstGreet = "Come in, come in! You're just the adventurers I've been searching for. Perhaps you could do a little favor for an old lady? Oh, I'll put on some tea.",
	Greet = "Come in, come in! You're just the adventurers I've been searching for. Perhaps you could do a little favor for an old lady? Oh, I'll put on some tea."
}

LocalizeAll.Quests["NPC = 488, Slot = 0"] = {
	Topic = "Robert",
	Ungive = "My son was stationed at that \01265523dreadful camp in the swamp\01200000. Maximus only sends someone to check on them once in a blue moon. Now, with the whole town in turmoil, they must've forgotten about him. Poor Robi!"
}

LocalizeAll.Quests["AmberQuest3"] = {
	Give = "\01265523Robert\01200000 must be sitting in that wretched \01265523camp\01200000 all alone, cold, wet, and hungry, with no one to look after him. Would you be kind enough to deliver this crate to him? Don't worry, I'll pay you in advance for your trouble.",
	Quest = "\"Worrying Mother\"\
Julia Greene, Amber Island, Port Island\
\
Deliver a stash of goods to Julia's son, Robert, who is stationed at the swamp camp.",
	Topic = "Quest: Worrying Mother",
	Undone = "The food will cool down and spoil if you don't hurry up. My son is waiting for you!"
}

--------------------------------------------------------------------------------
-- (489) James Halloran
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 489, Slot = -1"] = {
	FirstGreet = "Greetings. I'm the \01265523guardmaster\01200000 here, in charge of town security and overseeing the jail. What can I do for you today?",
	Greet = "Greetings. I'm the \01265523guardmaster\01200000 here, in charge of town security and overseeing the jail. What can I do for you today?"
}

LocalizeAll.Quests["NPC = 489, Slot = 0"] = {
	Topic = "Crime",
	Ungive = "With the level of crime in this town so low, I'm practically bored to death. It's so peaceful here that dealing with \01265523Conrad's\01200000 antics is the highlight of my week. A guardmaster could use a bit more excitement, you know?"
}

LocalizeAll.Quests["NPC = 489, Slot = 1"] = {
	Done = "*Guardmaster Halloran smirks as he accepts the payment.*\
\
Ah, another contribution to my \"Conrad Fund\". At this rate, I'll be retiring early.\
\
Thanks for the business.",
	TopicGiven = "Pay: Conrad Hawk (500g)",
	Undone = "*The guardmaster examines the offered amount with a raised eyebrow.*\
\
You think this is enough? For this amount, Conrad might as well take up permanent residence in my cell. \01265523Come back when you've got the full amount\01200000. I'm not running a charity here."
}

--------------------------------------------------------------------------------
-- (490) Thomas Beck
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 490, Slot = 0"] = {
	Topic = "Ex-Miner",
	Ungive = "I'm the last of the old dwarven miners from the amber extraction days, decades ago. Those were hard times, but they paid off. I've accumulated enough wealth over the years, and now, I'm relishing my retirement."
}

LocalizeAll.Quests["NPC = 490, Slot = 1"] = {
	Topic = "Abandoned Mines",
	Ungive = "I spent my younger years in the abandoned mines in the northeast part of the island, mining amber. Everything changed when a huge monster showed up and tore through the place. I tried to stand up to it, but it knocked my \01265523family sword\01200000 from my hand and I had to run for it. I'm still embarrassed about losing that sword.\
\
Nobody's been brave enough to go near those mines since then."
}

LocalizeAll.Quests["AmberQuest4"] = {
	After = "I can't thank you enough for returning this precious heirloom to me.",
	Done = "*His eyes widen in amazement as he beholds \01265523the sword\01200000 you present to him. A smile breaks across his weathered face, and he begins quietly sobbing.*\
\
This is the sword of my family, the very one I lost years ago in those forsaken mines. I never thought I'd see it again. Thank you, truly, from the bottom of my heart. I must insist on giving you a proper reward. The sword's worth more to me than money.",
	GreetDone = "Greetings, friends! You are always welcome here.",
	Topic = "Quest: Family Sword",
	TopicDone = "Thanks: Family Sword",
	Undone = "false"
}

--------------------------------------------------------------------------------
-- (491) Conrad Hawk
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 491, Slot = 0"] = {
	Topic = "Brawling",
	Ungive = "Ah, brawling, there's nothing quite like it. You see, there's a certain art to landing the perfect punch, especially when it's someone's nose at the tavern on a lively evening. The thrill, the adrenaline rush... it's just how I like to unwind."
}

LocalizeAll.Quests["AmberQuest11"] = {
	Give = "Name's Conrad Hawk. You might've heard about my little scuffles at the inn. Look, I've got a situation that needs handling, and I can't do it from in here. How about you help me out?\
\
\01265523Find Guardmaster James Halloran\01200000. He's the one who can get me out of this mess. \01265523Lives near the bridge on the western part of town\01200000. Pay him the bail, and I'll owe you.",
	Quest = "\"Bail out\"\
Conrad Hawk, Amber Island, Jail\
\
Pay Guardmaster James Halloran, who resides near the bridge on the island's western part, to release Conrad Hawk.",
	Topic = "Quest: Bail out!",
	Undone = "Are we done yet? I'm not one for sitting around, and this place isn't exactly lively. Hurry it up, will ya? I've got places to be and scores to settle."
}

--------------------------------------------------------------------------------
-- (492) Urist Alesworth
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 492, Slot = 0"] = {
	Topic = "Oak Home",
	Ungive = "We're descendants of the \01265523Alesworth clan\01200000, had our hands in the second expedition and all that. Our great-granddad, he built our home right under a sprouting oak on this very hill. Then, the oak got chopped and this tavern was built right where it stood. So, here we are, running the place. "
}

LocalizeAll.Quests["AmberQuest1"] = {
	After = "I owe you a big one, adventurers. Thanks to you, my family and I can finally take back our old home. We're truly grateful for your help.",
	Done = "You got them! Don't give me that look. I didn't say these were common rats. If it was just common rats, I'd hardly need adventurers! Here's compensation for your efforts.",
	Give = "Me and my brother are considering fixing up our \01265523old family home\01200000. It's been ages since we've stepped foot in there, and it seems the local fauna have turned it into their own little stinkin' den!\
\
So, I need you to head over and \01265523clear out those rats\01200000. For seasoned adventurers like yourselves, it should be a walk in the park, right? Consider it quick money in your pocket.",
	Quest = "\"Rat Problem\"\
Urist Alesworth, Amber Island, Powder Keg Inn\
\
Get rid of the rats from Oak Hill Cottage, situtated under the Powder Keg Inn at Port Island.",
	Topic = "Quest: Rat Problem",
	TopicDone = "Thanks: Rat Problem",
	Undone = "I'm still hearing squeaking from down below, which means those pests are still around. The job's not done yet!"
}

LocalizeAll.Quests["NPC = 492, Slot = 2"] = {
	Topic = "Traps",
	Ungive = "Traps, you ask? Well, me and my brother tried to deal with the rat problem ourselves. Built traps, baited them just right, and thought we had it all handled. Problem is, these rats are smarter and meaner than we expected. They broke free of most of our traps or outright ignored them.\
\
The traps are still there, though, and they will catch more than rats if you are not careful. Watch your step down there. Last thing we need is you getting caught in one of our contraptions on top of everything else."
}

--------------------------------------------------------------------------------
-- (493) Harvey Yap
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 493, Slot = -1"] = {
	FirstGreet = "New people! Welcome to the Amber Island.",
	Greet = "Good to see you again. Care for a cup of tea?"
}

LocalizeAll.Quests["NPC = 493, Slot = 0"] = {
	Topic = "Amber Bank",
	Ungive = "Have you had a chance to check out the Amber Bank? It's massive: practically a fortress. My dad's one of the folks who keeps it running. Now, everyone talks about trade and low taxes being the lifeblood of the island's prosperity, but according to my dad, the true secret is the bank. It's where all the kings and top merchants stash their riches. Naturally, nobody wants to mess with a place that guards so much wealth."
}

LocalizeAll.Quests["AmberQuest2"] = {
	After = "I'm overjoyed to see my coin again! It's clear I need to break my tossing habit if I want to keep it safe. Thank you for your help. I won't forget this.",
	Done = "What? You've found it? You can't imagine how relieved and happy I am! I'll be sure to be more careful with it from now on. Here's your reward, adventurers, as promised.",
	Give = "I possess a special \01265523coin\01200000, a family heirloom passed down from my father. It has a long and storied history within our family.\
\
You see, um, I've developed a habit of flipping it in the air while strolling through the streets. Unfortunately, disaster struck recently. \01265523A black crow snatched the coin mid-air and flew off with it\01200000, leaving me... coinless. *sobs*\
\
If you're willing to find it for me, I'm prepared to offer a substantial reward.",
	GreetDone = "Ah, my favourite adventurers. I'm so happy to see you again. Come in, make yourself comfortable.",
	Quest = "\"Lucky Coin\"\
Harvey Yap, Amber Island, Town\
\
Find the ancient golden coin and bring it to his owner.",
	Topic = "Quest: Lucky Coin",
	TopicDone = "Thanks: Lucky Coin",
	Undone = "Still no luck finding that coin? What I'm am even saying, of course there's no luck. I lost it! *sobs*\
\
Maybe that crow has a nest somewhere nearby..."
}

--------------------------------------------------------------------------------
-- (494) Robert Stevenson
--------------------------------------------------------------------------------

LocalizeAll.Quests["AmberQuest7"] = {
	After = "Cheers for delivering yourselves right into our \01265523ambush!\01200000 Couldn't have made it easier if you tried!",
	Give = "Hail to you! If you don't mind, I really could use some muscle here. You see, some time ago I was attacked by a sea monster. My ship crashed into the island and I fled.\
\
Can you \01265523help me retrieve some of the goods?\01200000 They should be on the \01265523east side of Amber Island\01200000, at an \01265523unusual looking tree\01200000. I could do it by myself if it wasn't for dangers that inhabit the island.",
	GreetDone = "Surprise, landlubbers! Ye thought ye'd be finding treasure, but instead, ye found us!",
	Quest = "\"Old Sea Dog\"\
Robert Stevenson, Follower\
\
Find the old sailor's lost loot near a unique tree on Amber Island's east side.",
	Topic = "Quest: Old Sea Dog",
	TopicDone = "Thanks: Old Sea Dog",
	Undone = "Set your course straight for the treasure on the \01265523east side of Amber Island\01200000, at that \01265523unusual tree\01200000. No beast or man shall keep us from our prize."
}

LocalizeAll.Quests["NPC = 494, Slot = 1"] = {
	Topic = "What the...",
	Ungive = "Ye've walked the plank right into me \01265523trap\01200000, landlubbers! There be no sea monster here, only the consequences of crossing paths with a pirate. Now, let's see if ye can fight men as well as beasts."
}

--------------------------------------------------------------------------------
-- (495) Martha Blaine
--------------------------------------------------------------------------------

LocalizeAll.Quests["AmberQuest5"] = {
	After = "Thank you so much for bringing Laurie home. Our family will forever be grateful for what you've done.",
	Done = "I cannot tell you how much it means to see Laurie safe and sound! Your bravery and kindness have brought our family back together. Here is your well-deserved reward. Thank you from the bottom of my heart.",
	Give = "Please, I am begging you, help me! My daughter \01265523Laurie\01200000 has been taken by cruel \01265523ratmen\01200000. They are demanding a ransom of \012655231000\01200000 gold pieces, to be delivered to the \01265523north-west island\01200000.\
\
Could you possibly deliver the ransom and personally escort her back home safely?",
	Quest = "\"Ransom\"\
Martha Blaine, Amber Island, Town\
\
Laurie Blaine has been kidnapped by vicious ratmen. The ransomer is awaiting the ransom at Apple Island, located in the north-west part of the islands. Deliver the ransom or rescue her, then safely escort her back home to her mother.",
	Topic = "Quest: Ransom",
	TopicDone = "Thanks: Ransom",
	Undone = "Why are you still here? Please, my daughter's safety is at stake. Deliver the ransom and bring her back to me as soon as possible, please."
}

LocalizeAll.Quests["NPC = 495, Slot = 1"] = {
	Done = "*Upon hearing the kidnappers' new demands, Martha's face crumples in despair. Clutching a bag of gold tightly in her trembling hands, she thrusts it towards you.*\
\
 This is all I have, every last coin. Please, take it. Maybe it is enough to hire some help? I beg you, Laurier is all I've got. You must bring her back to me!\
\
*Her eyes brim with tears.*",
	Topic = "There's a problem..."
}

LocalizeAll.Quests["NPC = 495, Slot = 2"] = {
	Topic = "Financial Issues",
	Ungive = "You heard? It has been one misfortune after another. First, the Archmage's mist only clouded our skies, but now he forces us to pay his exorbitant fees for our own protection. Then, my husband finds himself unable to return from his travels, trapped abroad by the same cursed mist.\
\
And as if to add insult to injury, our dear daughter Laurie was kidnapped. Each event on its own is a strain, but together, they have nearly drained our coffers dry.\
\
These are indeed dire times for the Blaine household."
}

--------------------------------------------------------------------------------
-- (496) Otho Robeson
--------------------------------------------------------------------------------

LocalizeAll.Quests["AmberQuest6"] = {
	After = "Let's discuss your reward at my home \01265523after I'm released\01200000 from this disgusting hole. Don't forget to bring the ring.",
	Done = "You actually did it? You cannot imagine my relief. I'll be stuck here for a \01265523few more hours\01200000, but once I'm out, \01265523visit my house\01200000 and we will discuss your reward. Don't forget to \01265523bring the ring.\01200000",
	Give = "Ah, so you are the newly-arrived fortune seekers? You're precisely the sort of individuals I require at this moment.\
\
My need is one of a discreet and delicate nature, calling for a particular set of skills I believe you possess.\
\
His name is \01265523Michael Cassio\01200000. He resides not far from here, \01265523between our town and Castle Amber\01200000. My request is simple: you must \01265523kill Cassio\01200000 for me. This man has inflicted a grievous betrayal upon my house by dishonoring my wife.\
\
I offer this \01265523ring\01200000 as advance payment. You may, of course, sell it and run away: a risk I am prepared to take. However, should you fulfill your commitment and then \01265523return the ring\01200000 to me, I assure you, your reward will be most generous indeed.",
	Quest = "\"Revenge\"\
Otho Robeson, Amber Island, Jail\
\
Locate and eliminate Michael Cassio. He resides to the east of Amber Town, situated between the town and Castle Amber.",
	Topic = "Quest: Revenge",
	TopicDone = "Thanks: Revenge",
	Undone = "The clock is ticking. Do what you have to do. End Michael Cassio."
}

LocalizeAll.Quests["NPC = 496, Slot = 1"] = {
	Topic = "Failed: Revenge",
	Ungive = "You think you're clever, siding with Michael against me? You will \01265523regret\01200000 this. Mark my words, you have not seen the last of me!"
}

LocalizeAll.Quests["NPC = 496, Slot = 2"] = {
	Topic = "Thanks: Revenge",
	Ungive = "Thank you for dealing with Cassio. I appreciate your discretion and effectiveness. I look forward to \01265523collaborating\01200000 with you again in the future."
}

LocalizeAll.Quests["NPC = 496, Slot = 3"] = {
	Give = "Here is your well-deserved reward. Do you have the \01265523ring?\01200000 I'll gladly add a bonus if you do.",
	Topic = "Reward?"
}

--------------------------------------------------------------------------------
-- (497) Desdemona Robeson
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 497, Slot = 0"] = {
	Topic = "Jealous Husband",
	Ungive = "My husband, he's driven by such fierce jealousy, especially concerning me. It's like a madness that clouds his judgment. Just recently, he brutally attacked Michael Cassio, convinced he was involved in an affair with me. There's no reasoning with him when he gets these notions in his head. It's all so baseless, yet he believes it with every fiber of his being. It's tearing us apart."
}

--------------------------------------------------------------------------------
-- (498) Michael Cassio
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 498, Branch = '', Slot = 0"] = {
	Topic = "Otho Robeson",
	Ungive = "That Otho Robeson is a complete lunatic! He beat me to a pulp, all because of some delusional idea that I was involved with his wife. I swear, the man's lost his mind! I've done nothing to deserve that kind of treatment. He's a menace, driven by irrational jealousy, and frankly, he's dangerous. Everyone needs to watch out for him. He's completely out of control."
}

LocalizeAll.Quests["NPC = 498, Branch = 'Confrontation', Slot = 0"] = {
	Give = "What? Otho sent you? Well, he's picked the wrong person to intimidate. I won't go down without a \01265523fight\01200000, you lowlifes. You've underestimated me. I'm ready for whatever you've planned. Bring it on.",
	Topic = "Kill Michael"
}

LocalizeAll.Quests["NPC = 498, Branch = '', Slot = 1"] = {
	Topic = "Quest: Revenge",
	Ungive = "What is the meaning of this?"
}

LocalizeAll.Quests["NPC = 498, Branch = 'Confrontation', Slot = 1"] = {
	Give = "Thank you for choosing the path of honor. With the \01265523ring\01200000 as evidence of Otho's dark intentions, we have a chance to bring the truth to light. Let's get to the mayor as quickly as possible.",
	Topic = "Take his side",
	Ungive = "*You can't approach Michael with this option without a proof - you need that \01265523ring\01200000 Otho gave you.*"
}

LocalizeAll.Quests["NPC = 498, Branch = '', Slot = 2"] = {
	Give = "We shouldn't loose any time, let's go \01265523see the mayor\01200000 and tell him everything.",
	Topic = "Well?"
}

LocalizeAll.Quests["NPC = 498, Branch = '', Slot = 3"] = {
	Topic = "Thanks: Revenge",
	Ungive = "I'm glad that you've chosen the path of honor. You will always be a welcome guest at my home."
}

--------------------------------------------------------------------------------
-- (499) Howard Carter
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 499, Slot = 0"] = {
	Topic = "Saint Nourville",
	Ungive = "Many years ago, during the earliest days of amber mining on this island, a tragic accident occurred. The \01265523First Expedition\01200000 was buried deep underground due to an unexpected avalanche. Only one dwarf, later known as \01265523Saint Nourville\01200000, was spared from this calamity.\
\
Driven by a profound sense of duty, he dedicated every ounce of his energy to sustain the lives of the trapped miners. He tirelessly dropped food for them, worked to clear the passage, and wove ropes for their rescue, all without a wink of sleep or a bite of food for several days. His effort paid off, and he successfully orchestrated their rescue.\
\
In gratitude, the miners established a \01265523temple in his honor\01200000 and erected a \01265523statue in the swamp\01200000 to honor his heroic deed."
}

LocalizeAll.Quests["NPC = 499, Slot = 1"] = {
	Topic = "First Expedition",
	Ungive = "It's believed that amber on this island was first discovered quite by chance by a marooned sailor who managed to survive here alone for four years. After his eventual rescue, he assembled a group of fortune seekers who would become the initial mining team, initiating what is now known as \"The First Expedition.\" \
\
This marked the dawn of civilization on Amber Island. The name of this resourceful founder, however, remains lost to history."
}

LocalizeAll.Quests["AmberQuest8"] = {
	After = "There's some fascinating stuff here in the swamp, but digging through this muck is a challenge. Your help has been invaluable in making it possible.",
	Done = "Awesome job, folks. You've really helped me out. If you ever find yourselves near the swamp, \01265523drop by and see what we're uncovering\01200000.",
	Give = "I've got some archaeological work to do in the swampy area on the \01265523southern island\01200000, but it's crawling with nasty \01265523lizards\01200000. Could you clear them out for me? I need that area safe to dig.",
	Quest = "\"Swamp Creatures\"\
Howard Carter, Amber Island, Town\
\
Clear out the hostile lizards in the swampy area on the southern island so Howard Carter can proceed with his archaeological work.",
	Topic = "Quest: Swamp Creatures",
	TopicDone = "Thanks: Swamp Creatures",
	Undone = "Those creatures are still causing trouble on the \01265523southern island\01200000. I can't start my work with them around."
}

--------------------------------------------------------------------------------
-- (500) John Constantine
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 500, Slot = -1"] = {
	FirstGreet = "Ah, welcome! I'm John Constantine, a warlock specializing in \01265523demonic studies\01200000. I see many adventurers pass through in search of fortune. What adventures bring you to our enchanted shores today?",
	Greet = "Ah, welcome! I'm John Constantine, a warlock specializing in \01265523demonic studies\01200000. I see many adventurers pass through in search of fortune. What adventures bring you to our enchanted shores today?"
}

LocalizeAll.Quests["AmberQuest9"] = {
	After = "Thanks to you our island is now free from demonic influence. On behalf of the entire town, I extend our deepest gratitude. You've done a great service for us all.",
	Done = "Excellent work! I can sense even the air is a bit fresher now. You've successfully cleansed the area of the Archmage's foul magic. Here's the gold you deserve for your work.",
	Give = "Before he started using goblins, Archmage Magnus placed several demonic altars across the island, which summoned demons he used to keep the village in line. Thanks to my magic and adventurers like you, there's only \01265523one altar left\01200000. It's in the woods on the southern island. Head there, and use \01265523this scroll\01200000 to cast a spell that will cleanse the area of the Archmage's corrupting magic. Be warned: unlike the other altars, the \01265523demon\01200000 protecting this altar is powerful. It will likely appear when you begin the cleansing.",
	Quest = "\"Ritual\"\
John Constantine, Amber Island, Swamp Island Forest\
\
Summon and defeat the demon at the altar in the forested area of the southern island.",
	Topic = "Quest: Ritual",
	TopicDone = "Thanks: Ritual",
	Undone = "Don't forget, to complete the ritual. You must summon and defeat the \01265523demon\01200000 at the altar on the southern island using this magical scroll."
}

LocalizeAll.Quests["NPC = 500, Slot = 1"] = {
	Topic = "Demons",
	Ungive = "Demons are vile abominations, the embodiment of evil. They never bring anything good into our world. Their origins are shrouded in mystery, but their presence is always a blight."
}

--------------------------------------------------------------------------------
-- (501) Samantha Ferrum
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 501, Slot = -1"] = {
	FirstGreet = "You seem like a capable band of adventurers. If you ever come across a \01265523piece of amber\01200000, consider bringing it to me. I'm willing to offer you \01265523double\01200000 its usual price.",
	Greet = "You seem like a capable band of adventurers. If you ever come across a \01265523piece of amber\01200000, consider bringing it to me. I'm willing to offer you \01265523double\01200000 its usual price."
}

LocalizeAll.Quests["NPC = 501, Slot = 0"] = {
	Done = "Wonderful piece! Please come again and bring more amber.",
	Topic = "Sell: Amber for 300g",
	Undone = "It appears you don't possess any suitable amber. Should you come across any, please return."
}

--------------------------------------------------------------------------------
-- (502) Amelia Lightfeather
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 502, Slot = -1"] = {
	FirstGreet = "Greetings, fellow traveler! If you're in need of an extra boost on your journeys, I have a \01265523collection of \"Jump\" spell scrolls\01200000, gathered during my own adventures.\
\
Since I no longer have a need for these scrolls, I'm looking to sell them to someone who can put them to good use.",
	Greet = "Greetings, fellow traveler! If you're in need of an extra boost on your journeys, I have a \01265523collection of \"Jump\" spell scrolls\01200000, gathered during my own adventures.\
\
Since I no longer have a need for these scrolls, I'm looking to sell them to someone who can put them to good use."
}

LocalizeAll.Quests["NPC = 502, Slot = 0"] = {
	Done = "I'm happy to see the scrolls go to someone who can use them. Thank you for buying, and may your adventures be both exciting and profitable.",
	Topic = "Buy: Jump Scroll, 250g",
	Undone = "I get that they're not flying off the shelves, and I have plenty, but they still cost me quite a bit of effort to acquire. I can't part with them unless you have the full amount."
}

--------------------------------------------------------------------------------
-- (504) Julia McBane
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 504, Slot = -1"] = {
	FirstGreet = "Greetings, travelers! I am the principal teacher of this island, guardian of its exclusive knowledge. Today, I offer you an invaluable opportunity to delve into a \01265523lecture\01200000 steeped in the unique wisdom of our land. This session is available for \012655231500g\01200000, an investment that promises to enrich your journey with profound insights and expertise found nowhere else.",
	Greet = "Greetings, travelers! I am the principal teacher of this island, guardian of its exclusive knowledge. Today, I offer you an invaluable opportunity to delve into a \01265523lecture\01200000 steeped in the unique wisdom of our land. This session is available for \012655231500g\01200000, an investment that promises to enrich your journey with profound insights and expertise found nowhere else."
}

LocalizeAll.Quests["NPC = 504, Slot = 0"] = {
	After = "You've already attended all the classes available for the season. I can't let you pay for what you already know. You already know everything I can teach you.",
	Done = "An investment in knowledge is the best kind of investment. You won't regret your decision; it's worth every coin. Now, follow me...",
	Topic = "Buy: Lecture (+1000xp) for 1500g",
	Undone = "While I firmly believe that knowledge is power, it also comes with its cost. Unfortunately, without the necessary gold, I cannot share this powerful wisdom with you."
}

--------------------------------------------------------------------------------
-- (505) Derick McBane
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 505, Slot = -1"] = {
	FirstGreet = "Welcome to the \01265523Mercenary Guild\01200000, adventurers. You're in the right place if you seek skilled companions for your journey. How can I assist you today?",
	Greet = "Welcome to the \01265523Mercenary Guild\01200000, adventurers. You're in the right place if you seek skilled companions for your journey. How can I assist you today?"
}

LocalizeAll.Quests["NPC = 505, Branch = '', Slot = 0"] = {
	Topic = "Mercenaries",
	Ungive = "Mercenaries, like tools in your kit, can turn the tide of your quests. Each one is unique, with their own strengths and quirks. For a fee, you can \01265523enhance\01200000 their abilities and \01265523summon\01200000 them to your side a few times each \01265523day\01200000. Should they fall or wander off, come back to me. I'll sort it out."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse0', Slot = 1"] = {
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse0', Slot = 1 +"] = {
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse0', Slot = 1 + +"] = {
	Done = "Lost the mercenary, have you? No matter. With a bit of magic and the right price, I can have him standing, ready for battle once again, right here, right now.",
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse1', Slot = 1"] = {
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse1', Slot = 1 +"] = {
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = 'MercsBrowse1', Slot = 1 + +"] = {
	Done = "Lost the mercenary, have you? No matter. With a bit of magic and the right price, I can have him standing, ready for battle once again, right here, right now.",
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

LocalizeAll.Quests["NPC = 505, Branch = '', Slot = 3"] = {
	Topic = "Browse: Mercenaries",
	Ungive = "Of course. We've got a range of skilled fighters, each with their own specialties. Take your pick, but remember - quality comes at a price"
}

LocalizeAll.Quests["NPC = 505, Branch = '', Slot = 4"] = {
	Done = "If any of your mercenaries are missing, just let me know. I'll ensure they're found and returned to your side promptly, no matter their specialty.",
	Topic = "Find and Return Mercenaries (100g)",
	Undone = "It seems your pockets aren't deep enough for my services. Come back when you've got the coin. Quality defense doesn't come cheap, after all."
}

--------------------------------------------------------------------------------
-- (506) Ella Borg
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 506, Slot = -1"] = {
	FirstGreet = "I'm an amateur glassworker. I can sell you \01265523empty flasks\01200000 for your alchemical needs for 25g.",
	Greet = "I'm an amateur glassworker. I can sell you \01265523empty flasks\01200000 for your alchemical needs for 25g."
}

LocalizeAll.Quests["NPC = 506, Slot = 0"] = {
	Done = "Though I'm still mastering my craft, this flask is made to withstand the rigors of alchemy. Thank you for your purchase.",
	Topic = "Buy: Empty Flask for 25g",
	Undone = "I'm sorry, but even though it's quite affordable, I must ask for the full price. Crafting, even at this level, demands time and materials."
}

--------------------------------------------------------------------------------
-- (507) Jane Goodwin
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 507, Slot = -1"] = {
	FirstGreet = "Greetings!\
\
I make \01265523red\01200000 and \01265523blue\01200000 potions for my brother at Saint Nourville Cathedral. I've got a few extra potions on hand that I could offer you.",
	Greet = "Greetings!\
\
I make \01265523red\01200000 and \01265523blue\01200000 potions for my brother at Saint Nourville Cathedral. I've got a few extra potions on hand that I could offer you."
}

LocalizeAll.Quests["NPC = 507, Slot = 0"] = {
	Done = "Thank you for your purchase! I'm sure my potions will serve you well.",
	Topic = "Buy: Crate of Red Potions (x8) for 500g",
	Undone = "I'd love to help you out with a better price, but the potions are already priced lower when bought in bulk like this. I can't go any lower."
}

LocalizeAll.Quests["NPC = 507, Slot = 1"] = {
	Topic = "Buy more! (Cure Potion)",
	Ungive = "I'm glad you're interested in more potions, but I've just sold out my current stock. Give me a \01265523week\01200000 to prepare a fresh batch, and I'll have them ready for you."
}

LocalizeAll.Quests["NPC = 507, Slot = 2"] = {
	Done = "Thank you for your purchase! I'm sure my potions will serve you well.",
	Topic = "Buy: Crate of Blue Potions (x8) for 500g",
	Undone = "I'd love to help you out with a better price, but the potions are already priced lower when bought in bulk like this. I can't go any lower."
}

LocalizeAll.Quests["NPC = 507, Slot = 3"] = {
	Topic = "Buy more! (Mana Potion)",
	Ungive = "I'm glad you're interested in more potions, but I've just sold out my current stock. Give me a \01265523week\01200000 to prepare a fresh batch, and I'll have them ready for you."
}

--------------------------------------------------------------------------------
-- (508) Aldous Chapman
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 508, Slot = -1"] = {
	FirstGreet = "Welcome to Chapman residence. I am a well-known merchant here, ready to offer you an array of exquisite \01265523goods\01200000. Our island's treasures are renowned far and wide, and I'm here to provide you with the best trading experience.",
	Greet = "Welcome to Chapman residence. I am a well-known merchant here, ready to offer you an array of exquisite \01265523goods\01200000. Our island's treasures are renowned far and wide, and I'm here to provide you with the best trading experience."
}

LocalizeAll.Quests["NPC = 508, Slot = 0"] = {
	Done = "Thank you for your purchase. These bottles can only be bought here and can fetch a high price in mainland cities.",
	Topic = "Buy: Amber Apple Cider for 1500g",
	Undone = "If you don't have enough gold, you'll have to come back when you do."
}

LocalizeAll.Quests["NPC = 508, Slot = 1"] = {
	Done = "Here on Amber Island, we have a great love for coffee. Your sale is much appreciated!",
	Topic = "Sell: Coffee Beans for 3000g",
	Undone = "It appears you don't have any coffee beans with you."
}

--------------------------------------------------------------------------------
-- (509) Grimwald Hawk
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 509, Slot = 0"] = {
	Topic = "Conrad",
	Ungive = "I'm at my wit's end with my son, Conrad. He's always stirring up trouble, provoking others, and seeking out fights. It's a constant source of embarrassment. I wish he'd settle down, start a family, build a home, and lead a respectable life instead of wandering around like a aimless loafer. "
}

--------------------------------------------------------------------------------
-- (510) Alaric Shadoweaver
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 510, Slot = 0"] = {
	Topic = "Liberal Attitudes",
	Ungive = "This island is a sanctuary for those with an open-minded stance on magic. Here, it doesn't matter if you practice light or dark magic as long as you don't harm others. That's why my wife and I chose to settle here, seeking refuge from those who couldn't see beyond their prejudices."
}

LocalizeAll.Quests["NPC = 510, Slot = 1"] = {
	Topic = "Necromancy",
	Ungive = "Being a necromancer is just a profession, like any other, and doesn't inherently make one evil. I do understand where the distrust comes from. Many necromancers choose isolation, and their practices can be unsettling. But remember, not all of us wish to summon legions of human skeletons. Sometimes, a little chicken skeleton minion is all you need for company."
}

--------------------------------------------------------------------------------
-- (511) Mirabel Shadoweaver
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 511, Slot = 0"] = {
	Topic = "The Future",
	Ungive = "*Her speech is slow and stuttering.*\
\
Once we resolve the situation with Archmage Magnus, I plan to establish a \01265523guild of dark magic\01200000, providing a sanctuary for practitioners of all kinds of marginalized magical practices."
}

--------------------------------------------------------------------------------
-- (512) Bertram Smith
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 512, Slot = 0"] = {
	Topic = "Diversity",
	Ungive = "Ever wondered why this place is so full of individuals of different races? Our island's diversity stems all the way from its origin story. It was uninhabited before \01265523The First Expedition\01200000, which meant the first settlers were dwarves, but the island quickly became a bustling trading hub, attracting individuals of all races seeking wealth and opportunity. Despite our differences, the pursuit of prosperity brings us together."
}

LocalizeAll.Quests["NPC = 512, Slot = 1"] = {
	Topic = "Castle Amber",
	Ungive = "\01265523Saint Nourville\01200000 and the rest of \01265523the First Expedition\01200000 were good folk, but it's been generations since they were around. When Nourville's grandson Dargrin built \01265523Castle Amber\01200000, he was trying to make it look like one of the mainland castles. They say Dargrin and his descendants used to act like ambassadors for visitors from the mainland. Since then, various people have lived in the castle, but none of them have been dangerous. On this island the mayor is the only one with actual political power. I guess it was only a matter of time before someone like Archmage Magnus claimed the place."
}

--------------------------------------------------------------------------------
-- (513) Florian Flavius
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 513, Slot = 0"] = {
	Topic = "Ratmen Pirates",
	Ungive = "Sometimes, these ratmen pirates sneak onto the island under the cover of night. I think they want to carry out their deeds unnoticed. However, there are occasions when their presence brings chaos and disruption to the island, so I wouldn't say they're subtle either. Did you hear about how they grabbed \01265523Martha's daughter?\01200000"
}

--------------------------------------------------------------------------------
-- (514) Elisabeth
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 514, Slot = 0"] = {
	Topic = "Horse Statue",
	Ungive = "The story goes back to \01265523Maximus's\01200000 youthful days. In a fierce battle, he was gravely injured. His faithful horse, Stormhoof, raced tirelessly for half a day, bringing him back home to safety. Later, when he became mayor, he ordered the creation of a magnificent statue to honor the gallant creature. That's my husband. He's always been fond of grand symbolic gestures."
}

LocalizeAll.Quests["NPC = 514, Slot = 1"] = {
	Topic = "Failed Adventurers",
	Ungive = "There have been a lot of adventurers who tried to do something about Archmage Magnus. Maximus has been desperate to hire help, but the adventurers all inevitably end up dead. I know it's been keeping him up at night. He's doing what he can to make sure that the adventurers he sends after Magnus are competent, but the last group were veterans and they were still slaughtered."
}

--------------------------------------------------------------------------------
-- (515) Robert Greene
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 515, Slot = 0"] = {
	Topic = "Lizards",
	Ungive = "These swamp lizards are the real deal when it comes to local predators. Surprisingly, they're \01265523missing\01200000 the \01265523petrifying ability\01200000 of their mainland cousins."
}

LocalizeAll.Quests["NPC = 515, Slot = 1"] = {
	Done = "Upon receiving the letter, Sir Greene's expression is focused and serious. Without uttering a single word, he begins to pen a response, the quill scratching quickly across the parchment. Moments later, he finishes, folds the letter, and seals it before handing it back to the heroes.\
\
Then, breaking his silence, he says, \"Hurry, bring this back to the mayor as soon as possible.\"",
	Topic = "Quest: Legate",
	Undone = "If the Mayor tasked you to deliver a letter to me, where is the letter?"
}

LocalizeAll.Quests["NPC = 515, Slot = 2"] = {
	After = "One of the most pieces of advice I've received as a soldier is to keep your socks dry. Being in the swamp makes this especially true and my momma knows it.\
\
Cherish you mothers, adventurers. Sometimes they can look out for you in ways no one else will.",
	Done = "Delivery from whom? My Mother? Again? *Sigh*\
\
I'm an annointed knight and a respected leader of our community, and she still treats me like a child. Oh well, let's at least see what she's sent... junk, lots of food and, of course, socks. And a note. *Sir Green quickly reads the note.*\
\
 I'm told to give you this purse of gold. The path through this swamp is dangerous, so I guess you deserve it.",
	TopicDone = "Thanks: Worrying Mother",
	TopicGiven = "Quest: Worrying Mother",
	Undone = "Hmm?"
}

--------------------------------------------------------------------------------
-- (516) Laurie Blaine
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 516, Slot = 0"] = {
	Done = "You do not look like those dreadful ratmen pirates. Are you here to rescue me?",
	Topic = "Rescue!"
}

LocalizeAll.Quests["NPC = 516, Slot = 1"] = {
	Topic = "Hostage",
	Ungive = "Surprisingly, despite their fearsome reputation, the ratmen pirates treated me quite well. They provided me with food and even respected my privacy. It is strange to think such menacing figures could show a hint of kindness. "
}

--------------------------------------------------------------------------------
-- (517) Julius Cheeser
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 517, Slot = -1"] = {
	FirstGreet = "Are you feeling a bit disoriented, pal? In search of a thrilling adventure and the promise of treasure, perhaps? It seems you've stumbled upon the perfect opportunity.",
	Greet = "Are you feeling a bit disoriented, pal? In search of a thrilling adventure and the promise of treasure, perhaps? It seems you've stumbled upon the perfect opportunity."
}

LocalizeAll.Quests["NPC = 517, Slot = 0"] = {
	Topic = "Favor",
	Ungive = "Do me a favor, will you? Locate the \01265523Blaine residence\01200000 in Amber Town and deliver a message for me. Tell them to think faster if they wish to see their daughter again. \
\
Maybe we'll share the loot together, friend."
}

LocalizeAll.Quests["NPC = 517, Slot = 0 +"] = {
	Topic = "Laurie Blaine",
	Ungive = "The lass is safe and sound, snug as a bug in a rug! But she's itching to see home. Just make sure you \01265523bring the gold\01200000, all of it. We wouldn't want to prolong her stay, now would we?"
}

LocalizeAll.Quests["NPC = 517, Slot = 1"] = {
	Topic = "Pirate Life",
	Ungive = "With everyone on Amber Island losing their heads over the mist crisis, they ain't watching their bloody valuables. Perfect time for a quick snatch, if you ask me."
}

LocalizeAll.Quests["NPC = 517, Slot = 2"] = {
	Done = "Ah, bless your hearts, you've brought the gold! But, oh dear, what's this? Just 1000 gold pieces? My, my, they must've misheard me. \01265523I distinctly recall saying 5000 gold\01200000, not a coin less. Run along now, \01265523fetch\01200000 the proper amount. \
\
No hard feelings, eh? Just a little misunderstanding! *bursts into snorting laughter*",
	Topic = "Pay: Ransom (1000g)",
	Undone = "Are you messsing with me, friend? You don't have enough gold."
}

LocalizeAll.Quests["NPC = 517, Slot = 3"] = {
	Done = "Nice doing business with you, friend. Here's the gal, now get lost.",
	Topic = "Pay: Ransom (5000g)",
	Undone = "Are you messsing with me, friend? You don't have enough gold."
}

--------------------------------------------------------------------------------
-- (518) Buster Squeky
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 518, Slot = -1"] = {
	FirstGreet = "Ah, my dear saviors...\
\
To think, my own kin turned against me, but here you are, bold and brave, setting me free. How delightfully unpredictable.\
\
Put my skills to use, friends. At your side, I'll guide you through the shadows and get the dirty jobs done.",
	Greet = "Ah, my dear saviors...\
\
To think, my own kin turned against me, but here you are, bold and brave, setting me free. How delightfully unpredictable.\
\
Put my skills to use, friends. At your side, I'll guide you through the shadows and get the dirty jobs done."
}

LocalizeAll.Quests["NPC = 518, Slot = 0"] = {
	Done = "Excellent choice. Just remember, while I may play in the shadows, my loyalty to you is as sharp and unwavering as my claws. Together, we'll be rich enough to do whatever we want.",
	Topic = "Hire: Ratman (0g)"
}

--------------------------------------------------------------------------------
-- (519) Samuel Krell
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 519, Slot = 0"] = {
	Topic = "Welcome!",
	Ungive = "Welcome to the Spirit Guild. If you'd like, you can donate to the \01265523restoration\01200000 of the \01265523Day of the Gods\01200000 pedestal. Your contributions help and could bring you blessings that assist in your adventures. It's a way to gain favor and protection for your journeys."
}

LocalizeAll.Quests["NPC = 519, Slot = 1"] = {
	After = "Thank you for your donation. May the blessings from the Day of the Gods pedestal help and protect you on your adventures.",
	Done = "Thank you for your donation. May the blessings from the Day of the Gods pedestal help and protect you on your adventures.",
	Topic = "Fix: Day of the Gods Pedestal (8000g)",
	TopicDone = "Thanks: Day of the Gods Pedestal",
	Undone = "Come back when you have enough gold."
}

--------------------------------------------------------------------------------
-- (521) Julius Cheeser
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 521, Slot = -1"] = {
	FirstGreet = "Where do you think you're going without an invitation, friend? Take one more step and we \01265523won't be so friendly\01200000 anymore.",
	Greet = "Where do you think you're going without an invitation, friend? Take one more step and we \01265523won't be so friendly\01200000 anymore."
}

LocalizeAll.Quests["NPC = 521, Slot = 4"] = {
	Topic = "Ignore warning"
}

LocalizeAll.Quests["NPC = 521, Slot = 5"] = {
	Topic = "Back off"
}

--------------------------------------------------------------------------------
-- (522) Pirate Stash
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 522, Slot = 3"] = {
	Done = "With a creaking sound, the chest's lid swings open to reveal its contents: a gleaming hoard of \012655231208 gold pieces\01200000, piled neatly inside, waiting to be claimed.",
	Topic = "Quest: Open Chest",
	Undone = "The chest is securely \01265523locked\01200000, its heavy lid refusing to budge. A distinct pirate insignia marks the lock, indicating a specific \01265523key\01200000 is needed to open it."
}

--------------------------------------------------------------------------------
-- (523) Sir Hoppington the Brave
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 523, Slot = -1"] = {
	FirstGreet = "Ah, greetings, noble adventurers! I am \01265523Sir Hoppington the Brave\01200000, at your service. I find myself in a bit of a pickle, and I require assistance of the highest order.",
	Greet = "Welcome back, adventurers? Any news about my missing pet?"
}

LocalizeAll.Quests["AmberQuest10"] = {
	After = "Thank you, brave souls, for returning my precious bunny. Your kindness won't be forgotten.",
	Done = "Joyous day! My heart swells with gratitude at the sight of my dear friend returned to me. You have my deepest thanks and the eternal gratitude of Sir Hoppington the Brave!",
	Give = "I've got a unique problem. My magical talking \01265523bunny\01200000 has gone missing, and I miss it terribly. I need your help to \01265523find it\01200000 quietly and bring it back. Will you help me?",
	GreetDone = "Ah, my valiant rescuers! Welcome back. Seeing my little companion frolicking once again fills me with immeasurable happiness. How may Sir Hoppington the Brave assist you today?",
	Quest = "Missing Pet\
Sir Hoppington the Brave, Amber Island, East Area\
\
Find and return Sir Hoppington's missing talking bunny.",
	Topic = "Quest: Missing Pet",
	TopicDone = "Thanks: Missing Pet",
	Undone = "Alas, my heart is heavy with worry, and my armor feels unusually burdensome without my little companion by my side. Have you perchance found any trace of my lost friend?"
}

LocalizeAll.Quests["NPC = 523, Slot = 1"] = {
	Topic = "Castle Amber",
	Ungive = "Here in the shadow of Castle Amber, we knights stand vigilant, guarding against any threats that might emerge from its darkened halls. Recently, it's become a \01265523stronghold for goblins\01200000, and our main task is to ensure they don't spill into the town and jeopardize our people's safety. It's a constant battle, holding the line here, but it's crucial to keep the peace and protect the locals from harm."
}

--------------------------------------------------------------------------------
-- (524) Bunny
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 524, Slot = -1"] = {
	FirstGreet = "Hello! Who are you? I wasn't expecting visitors.",
	Greet = "What's up?"
}

LocalizeAll.Quests["NPC = 524, Slot = 0"] = {
	Done = "Back to Sir Hoppington, huh? Alright, lead the way, but keep the carrots coming!",
	Give = "Sir Hoppington sent you? I do miss my warm bed... \01265523But why should I trust you?\01200000",
	GreetDone = "What's up, folks? Do you have more carrots? I really could use a bite you know.",
	Topic = "Quest: Missing Pet",
	Undone = "Hey, what's the big idea? I'm not just some toy to be picked up. \01265523Where's the trust\01200000, huh?"
}

LocalizeAll.Quests["NPC = 524, Slot = 1"] = {
	Topic = "Other Bunnies",
	Ungive = "I met another bunny in the field today and excitedly started a conversation. I talked and talked, but he just stared at me, munching on his carrot. I finally concluded he must be a little slow, or maybe he's just really good at keeping secrets!"
}

LocalizeAll.Quests["NPC = 524, Slot = 2"] = {
	Topic = "Home",
	Ungive = "I ventured out one day in search of the world's crunchiest carrots, and what an adventure it's been! I've hopped through fields, nibbled in gardens, and danced under moonlit skies...\
\
But now, I seem to have hopped a bit too far. I can't quite remember the way back to my original home."
}

--------------------------------------------------------------------------------
-- (525) Warder
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 0 +"] = {
	Topic = "Dismiss!"
}

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 0 + +"] = {
	Topic = "Fight?",
	Ungive = "I'm too tired, boss."
}

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 0 + + +"] = {
	Topic = "Dead",
	Ungive = "Apparently, this mercenary is \01264105dead\01200000. Seek help from Guildmaster."
}

LocalizeAll.Quests["NPC = 525, Branch = 'MercInfo', Slot = 0"] = {
	Topic = "About"
}

LocalizeAll.Quests["NPC = 525, Branch = 'ConfirmFire', Slot = 0"] = {
	Topic = "Good bye!"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeSelect', Slot = 0"] = {
	Topic = "Category: Common"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeCommon', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeOffense', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeDefense', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 1"] = {
	Topic = "Information"
}

LocalizeAll.Quests["NPC = 525, Branch = 'MercInfo', Slot = 1"] = {
	Topic = "Special Ability"
}

LocalizeAll.Quests["NPC = 525, Branch = 'ConfirmFire', Slot = 1"] = {
	Topic = "On second thought...",
	Ungive = "I was worried for a bit, boss."
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeSelect', Slot = 1"] = {
	Topic = "Category: Offense"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeCommon', Slot = 1"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeSelect', Slot = 2"] = {
	Topic = "Category: Defense"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeCommon', Slot = 2"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 3"] = {
	Topic = "Upgrade"
}

LocalizeAll.Quests["NPC = 525, Branch = 'MercInfo', Slot = 3"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 525, Branch = '', Slot = 4"] = {
	Topic = "Fire",
	Ungive = "Off I go then. If you need me, I'll be at the merc guild, probably just standing around."
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeSelect', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeCommon', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeOffense', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 525, Branch = 'UpgradeDefense', Slot = 5"] = {
	Topic = "Back"
}

--------------------------------------------------------------------------------
-- (526) Buster Squeky
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 0 +"] = {
	Topic = "Dismiss!"
}

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 0 + +"] = {
	Topic = "Fight?",
	Ungive = "Phew, I'm all tuckered out. Using my tricks really takes it out of me. Mind if I take a little breather before the next round of mischief?"
}

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 0 + + +"] = {
	Topic = "Dead",
	Ungive = "Apparently, this mercenary is \01264105dead\01200000. Seek help from Guildmaster."
}

LocalizeAll.Quests["NPC = 526, Branch = 'MercInfo', Slot = 0"] = {
	Topic = "About"
}

LocalizeAll.Quests["NPC = 526, Branch = 'ConfirmFire', Slot = 0"] = {
	Topic = "Good bye!"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeSelect', Slot = 0"] = {
	Topic = "Category: Common"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeCommon', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeOffense', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeDefense', Slot = 0"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 1"] = {
	Topic = "Information"
}

LocalizeAll.Quests["NPC = 526, Branch = 'MercInfo', Slot = 1"] = {
	Topic = "Special Ability"
}

LocalizeAll.Quests["NPC = 526, Branch = 'ConfirmFire', Slot = 1"] = {
	Topic = "On second thought...",
	Ungive = "Ah, changing our minds, are we? Can't say I blame you..."
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeSelect', Slot = 1"] = {
	Topic = "Category: Offense"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeCommon', Slot = 1"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeSelect', Slot = 2"] = {
	Topic = "Category: Defense"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeCommon', Slot = 2"] = {
	Done = "Upgrade successful!",
	Undone = "Not enough gold or you've reached maximum level of allowed upgrades."
}

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 3"] = {
	Topic = "Upgrade"
}

LocalizeAll.Quests["NPC = 526, Branch = 'MercInfo', Slot = 3"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 526, Branch = '', Slot = 4"] = {
	Topic = "Fire",
	Ungive = "Getting the boot, am I? Fair enough, fair enough. Can't say it's been boring! If you ever need a bit of sneaky again, you know where to find me."
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeSelect', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeCommon', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeOffense', Slot = 5"] = {
	Topic = "Back"
}

LocalizeAll.Quests["NPC = 526, Branch = 'UpgradeDefense', Slot = 5"] = {
	Topic = "Back"
}

--------------------------------------------------------------------------------
-- (527) Aedan Kelly
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 527, Slot = -1"] = {
	FirstGreet = "Hmm? Fancy a drink, stranger?",
	Greet = "Hmm? Fancy a drink, stranger?"
}

LocalizeAll.Quests["NPC = 527, Slot = 0"] = {
	Topic = "Regrets",
	Ungive = "Yeah, I was \01265523part of a group\01200000 that came here seeking adventure a fortune in gold. We fought our way through the \01265523west wing\01200000 of Archmage Magnus's Residence, even reached a \01265523teleportation pedestal\01200000. One of our own tried it and never came back. Then we were ambushed. I'm the sole survivor. \
\
Enough adventuring for me. I'm heading home!"
}

LocalizeAll.Quests["NPC = 527, Slot = 1"] = {
	Topic = "Magnus's Residence",
	Ungive = "The Archmage's Residence is a grand house in the \01265523southwestern part of Swamp Island\01200000. Inside, it's quite lavish, but don't let that fool you: it's teeming with elemental guards. Tough ones, and oddly, they seem at odds with each other. We tried to locate the Archmage but couldn't find him, only this blasted \01265523teleport stone\01200000. Our best guess was he's holed up in the \01265523central workshop.\01200000"
}

LocalizeAll.Quests["NPC = 527, Slot = 2"] = {
	Topic = "Quest: Investigation?",
	Ungive = "So, you're treading the path we did? You'll need all the luck you can get. We had a \01265523teleportation stone\01200000, something we used in the residence's western chamber. One of our team went through and vanished. But when we fled the archmage's residence, I lost the stone near an \01265523old swamp tree stump\01200000. If you can find it, perhaps you'll succeed where we failed - and maybe even uncover what happened to our lost companion."
}

LocalizeAll.Quests["NPC = 527, Slot = 2 +"] = {
	Done = "So, you're treading the path we did? You'll need all the luck you can get. Here, take this \01265523teleportation stone\01200000. We used it in the residence's western chamber. One of our team went through and vanished. Perhaps you'll have more success, maybe even find our lost companion.",
	Topic = "Quest: Investigation"
}

LocalizeAll.Quests["NPC = 527, Slot = 3"] = {
	Topic = "Teleportation Stone",
	Ungive = "We found this magical stone in a \01265523very weird place.\01200000 It was an eerie location where \01265523furniture floated\01200000 in space, defying all logic. Keep your eyes open for places that feel out of the ordinary; you never know what you might find."
}

--------------------------------------------------------------------------------
-- (528) Barnaby Whitfield
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 528, Slot = -1"] = {
	FirstGreet = "Ah, leave me alone! I've already spilled everything I know to the guards... There's nothing more to say.",
	Greet = "Ah, leave me alone! I've already spilled everything I know to the guards... There's nothing more to say."
}

LocalizeAll.Quests["NPC = 528, Slot = 0"] = {
	Topic = "Butler",
	Ungive = "Yes, I was Archmage Magnus's butler. Then he lost his mind, and just because I worked for him, I'm treated like a criminal! I'm innocent, yet here I am, suffering for his madness."
}

LocalizeAll.Quests["NPC = 528, Slot = 1"] = {
	Done = "Fine, fine. Magnus does have a \01265523secret hideout\01200000. It's less a home and more a magical lab, where he dabbles in teleportation and other things that involve bending reality. He could be in his bedroom or lost in one of those twisted realities he's so fond of. He's been spending more and more time outside our world.\
\
Here, take this \01265523medallion.\01200000 It may look insignificant, but it's imbued with magic. With it, you can use the \01265523teleportation platform\01200000 near the \01265523knights' camp in the swamp's southeastern region\01200000 to reach his hideout.",
	Topic = "Quest: Investigation"
}

--------------------------------------------------------------------------------
-- (529) Isabella Morland
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 529, Slot = -1"] = {
	FirstGreet = "Greetings, distinguished heroes, I come as an \01265523envoy of King Richard Ironheart\01200000, bearing a message of great import.",
	Greet = "Greetings, distinguished heroes, I come as an \01265523envoy of King Richard Ironheart\01200000, bearing a message of great import."
}

LocalizeAll.Quests["AmberEndQuest"] = {
	Give = "Heroes of Amber Island, your valor has caught the eye of \01265523King Richard Ironheart\01200000 himself. He extends an invitation to join him at the palace, where your courage can play a pivotal role in an event of great significance to the realm.\
\
The king's fleet awaits to escort you across the seas to the mainland, where your next great adventure beckons. Consider this \01265523voyage\01200000 a token of the realm's gratitude. Your passage is free, courtesy of King Richard Ironheart.",
	Quest = "\"Royal Audience\"\
Isabella Morland, Amber Island, Town Hall\
\
Embark on a voyage by ship to the mainland to attend an audience with King Richard Ironheart.",
	Topic = "Quest: Royal Audience",
	Undone = "Time is of the essence, noble heroes. While your deeds are many, the realm urgently requires your prowess. I urge you to hasten your preparations and \01265523set sail\01200000 with us to the mainland."
}

LocalizeAll.Quests["NPC = 529, Slot = 1"] = {
	Topic = "The End (Victory!)",
	Ungive = "Good job!"
}

--------------------------------------------------------------------------------
-- (530) Cedrick Boyce 
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 530, Slot = -1"] = {
	FirstGreet = "Ahoy there! Looking for a \01265523boat?\01200000 I can't go very far because of the mist nowadays, so I'm just waiting for a chance to use my skills again.",
	Greet = "Ahoy there! Looking for a \01265523boat?\01200000 I can't go very far because of the mist nowadays, so I'm just waiting for a chance to use my skills again."
}

LocalizeAll.Quests["NPC = 530, Slot = 0"] = {
	Topic = "The Mist",
	Ungive = "That unnatural mist circling the island is a real menace, \01265523messing with ship navigation.\01200000 Thankfully, it usually doesn't envelop the island itself, making boat travel in shallow waters a safer bet. Just point the way, and I'll steer us clear of the thick fog."
}

LocalizeAll.Quests["NPC = 530, Slot = 1"] = {
	Topic = "Travel: Arena"
}

LocalizeAll.Quests["NPC = 530, Slot = 1 +"] = {
	Topic = "Travel: Arena",
	Ungive = "Sorry, but the arena is currently closed and will reopen in 24 hours. Please come back later."
}

LocalizeAll.Quests["NPC = 530, Slot = 2"] = {
	Topic = "Travel: Castle Amber"
}

--------------------------------------------------------------------------------
-- (531) Cedrick Boyce 
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 531, Slot = -1"] = {
	FirstGreet = "Ahoy there! Ready to set sail?",
	Greet = "Ahoy there! Ready to set sail?"
}

LocalizeAll.Quests["NPC = 531, Slot = 0"] = {
	Topic = "Travel: Island Town"
}

--------------------------------------------------------------------------------
-- (532) Tobias Saltybeard
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 532, Slot = -1"] = {
	FirstGreet = "Ahoy! I'm Tobias Saltybeard, captain of this vessel",
	Greet = "Good to see you again. Maybe we'll be off on another voyage soon enough."
}

LocalizeAll.Quests["NPC = 532, Slot = 0"] = {
	Topic = "Arrival",
	Ungive = "Here we are, at port on Amber Island. We were lucky enough to get here before the \01265523magical mist\01200000 appeared again. Mind you, there's no way out of it until the mist clears, so it seems we'll be extending our stay a bit longer than expected. Best make the most of it, eh?"
}

--------------------------------------------------------------------------------
-- (533) Benjamin Barnacle
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 533, Slot = -1"] = {
	FirstGreet = "Ahoy, matey! May I introduce myself, Captain Benjamin Barnacle of the Black Betty. Welcome aboard. Looking to book passage?",
	Greet = "Welcome back. The Black Betty welcomes you."
}

LocalizeAll.Quests["NPC = 533, Slot = 0"] = {
	Topic = "Trade and Mist",
	Ungive = "This island, smack in the center of the vast ocean, serves as a pivotal point between the two continents. Most ships on intercontinental voyages make a stop here to resupply. However, the recent mist crisis has made it quite a challenge to reach. Navigating these waters has become a task only the bravest dare tackle. Lucky for me, the crew of the Black Betty don't lack for courage."
}

--------------------------------------------------------------------------------
-- (534) Safe Room
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 534, Slot = -1"] = {
	FirstGreet = "The safe room is an abandoned, old, and dusty space with a sturdy door that can be securely locked to keep monsters at bay. Despite its condition, it offers a brief respite for heroes to rest and heal.",
	Greet = "The safe room is an abandoned, old, and dusty space with a sturdy door that can be securely locked to keep monsters at bay. Despite its condition, it offers a brief respite for heroes to rest and heal."
}

--------------------------------------------------------------------------------
-- (536) Goblin Raider
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 536, Slot = -1"] = {
	FirstGreet = "Well, hello there!\
\
Congratulations, you've won a prize - a special dinner with the \01265523Troll Warchief\01200000 himself! And guess what? You're the main course! Hahaha! Alright, boys, let's show them to their seats!\
\
Get 'em!",
	Greet = "Well, hello there!\
\
Congratulations, you've won a prize - a special dinner with the \01265523Troll Warchief\01200000 himself! And guess what? You're the main course! Hahaha! Alright, boys, let's show them to their seats!\
\
Get 'em!"
}

LocalizeAll.Quests["NPC = 536, Slot = 0"] = {
	Topic = "Yikes!"
}

--------------------------------------------------------------------------------
-- (540) Thomas Guilden
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 540, Slot = -1"] = {
	FirstGreet = "Greetings, travelers. Thomas Guilden, clerk of the bank and occasional runner of errands. If you've come seeking assistance, you're in capable hands. How may I help you today?",
	Greet = "Greetings, travelers. Thomas Guilden, clerk of the bank and occasional runner of errands. If you've come seeking assistance, you're in capable hands. How may I help you today?"
}

LocalizeAll.Quests["NPC = 540, Slot = 0"] = {
	Topic = "Thieves",
	Ungive = "Adventurers have flooded Amber Island lately, all chasing the same thing - riches and fame by solving the archmage crisis. But when the work runs dry and the coin runs out, desperation kicks in. A lot of them start resorting to theft, smuggling, or worse.\
\
That's why we recommend purchasing the \01265523Merchant Guild's Seal of Approval\01200000 - it shows you're trustworthy and have the means to pay."
}

LocalizeAll.Quests["NPC = 540, Slot = 1"] = {
	After = "Ah, it's good to see the seal is in capable hands. I trust it's been useful in easing your dealings with the locals. Anything else I can assist with?",
	Done = "Well done. With this, the merchants will see you as trustworthy customers. Carry it with you, and you'll find doors opening where they were once shut. Best of luck out there.",
	Topic = "Buy: Seal of Approval for 1600g",
	Undone = "I'm afraid you don't have enough to cover the cost. Come back when you've gathered the required funds. Until then, the merchants likely won't take any chances."
}

--------------------------------------------------------------------------------
-- (541) Thomas Guilden
--------------------------------------------------------------------------------

LocalizeAll.Quests["NPC = 541, Slot = -1"] = {
	FirstGreet = "*Thomas Guilden steps forward, adjusting his well-worn satchel with a polite smile.*\
\
Ah, I couldn't help but notice the door shutting in your faces. Amber Island is overrun with adventurers these days - most of them broke and turning to theft. It's no wonder shopkeepers have grown wary.\
\
But if you're not like the rest, prove it. Head to the \01265523bank\01200000 and purchase the \01265523Merchant Guild's Seal of Approval\01200000. It's the only way to show the locals you're here to trade, not steal. What do you say?",
	Greet = "*Thomas Guilden steps forward, adjusting his well-worn satchel with a polite smile.*\
\
Ah, I couldn't help but notice the door shutting in your faces. Amber Island is overrun with adventurers these days - most of them broke and turning to theft. It's no wonder shopkeepers have grown wary.\
\
But if you're not like the rest, prove it. Head to the \01265523bank\01200000 and purchase the \01265523Merchant Guild's Seal of Approval\01200000. It's the only way to show the locals you're here to trade, not steal. What do you say?"
}

LocalizeAll.Quests["NPC = 541, Slot = 0"] = {
	Topic = "Ok..."
}
