Autonote('amberDungeonFountain5', 1, 'Amber Island, Secret Hideout: Entrance, +10 HP/SP restored')
