Autonote('amberFountain1', 1, 'Amber Island, Port Island: + 10 Hit and Spell points')
Autonote('amberWell1', 1, 'Amber Island, Port Island: Behind Powder Kegg Inn, +5 AC')
Autonote('amberWell2', 1, 'Amber Island, Town SW: Near Leary residence, +10 Might')
Autonote('amberWell3', 1, 'Amber Island, Swamp Island: Between Statue and Knight Camp, +5 Elemental Resistance')
