Autonote('amberDungeonFountain1', 1, 'Amber Island, Oak Hill Cottage: Entrance corridor, +5 AC')
