Autonote('amberDungeonFountain4', 1, 'Amber Island, Archmage Residence: Entrance, Main Hall, +10 HP/SP restored')
