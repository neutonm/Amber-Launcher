Autonote('amberDungeonFountain2', 1, 'Amber Island, Apple Cave: Entrance, near the mine cart, +20 Luck')
Autonote('amberDungeonFountain3', 1, 'Amber Island, Apple Cave: Temple, +10 SP restored')
