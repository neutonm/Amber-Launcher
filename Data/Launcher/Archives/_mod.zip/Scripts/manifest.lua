-- FILE:        manifest.lua
-- DESCRIPTION: Amber Island Mod information

return {
    name    = "Amber Island",
    game    = "mm7",
    version = "v1.1.0",
    author  = "Henrik Chukhran",
    website = "https://mightandmagicmod.com",
    updated = "10.09.2025"
}
